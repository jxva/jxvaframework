package db.rowset;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Create two tables, one is CUSTOMERS, the other is ORDERS.
 */
public class DBCreator {

	public static final String DRIVER = "org.apache.derby.jdbc.EmbeddedDriver"; //$NON-NLS-1$

	public static final String DERBY_CREATE = "jdbc:derby:TESTDB;create=true"; //$NON-NLS-1$

	public static final String DERBY_URL = "jdbc:derby:TESTDB"; //$NON-NLS-1$

	public static final String TABLE_CUSTOMERS = "CUSTOMERS"; //$NON-NLS-1$

	public static final String SQL_SELECT_CUSTOMERS = "SELECT * FROM CUSTOMERS"; //$NON-NLS-1$
    
    public static final String SQL_SELECT_ORDERS = "SELECT * FROM ORDERS"; //$NON-NLS-1$

	public static void main(String[] args) {
		// Load the driver
		try {
			Class.forName(DRIVER);
		} catch (ClassNotFoundException e) {
			System.out.println("Load driver failed: "); //$NON-NLS-1$
			e.printStackTrace();
			return;
		}

		Connection conn = null;
		Statement stmt = null;
		try {
			// Create Connection and Statement
			conn = DriverManager.getConnection(DERBY_CREATE);
			stmt = conn.createStatement();

			// Delete the tables if it has already exist.
			try {
				stmt.execute("DROP TABLE CUSTOMERS");
				stmt.execute("DROP TABLE ORDERS");
			} catch (SQLException e) {
				// Do nothing if the table does not exist.
			}

			// Create the table: CUSTOMERS
			String createTableSql = "CREATE TABLE CUSTOMERS(ID INTEGER NOT NULL,NAME VARCHAR(30) NOT NULL, REMARK VARCHAR(100))"; //$NON-NLS-1$
			stmt.execute(createTableSql);
			stmt
					.executeUpdate("INSERT INTO CUSTOMERS VALUES(1,'Tom', 'Tom is VIP.')"); //$NON-NLS-1$
			stmt.executeUpdate("INSERT INTO CUSTOMERS VALUES(2,'Jim', null)"); //$NON-NLS-1$
			// Create the table: ORDERS
			createTableSql = "CREATE TABLE ORDERS(ID INTEGER NOT NULL, USER_ID INTEGER NOT NULL, PRODUCT VARCHAR(100))"; //$NON-NLS-1$
			stmt.execute(createTableSql);
			stmt.executeUpdate("INSERT INTO ORDERS VALUES(1, 1, 'Book')"); //$NON-NLS-1$
			stmt.executeUpdate("INSERT INTO ORDERS VALUES(2, 1, 'Compute')"); //$NON-NLS-1$
			stmt.executeUpdate("INSERT INTO ORDERS VALUES(3, 2, 'Phone')"); //$NON-NLS-1$
		} catch (SQLException e) {
			System.out.println("Something wrong when creating db: "); //$NON-NLS-1$
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null) {
					stmt.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException e) {
				// ignore
			}
		}
	}
}
