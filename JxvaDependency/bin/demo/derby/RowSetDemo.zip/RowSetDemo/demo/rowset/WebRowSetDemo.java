package demo.rowset;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.SQLException;

import javax.sql.rowset.WebRowSet;

import com.sun.rowset.WebRowSetImpl;

import db.rowset.DBCreator;

public class WebRowSetDemo {

	public static void main(String[] args) throws SQLException, IOException,
			ClassNotFoundException {
		Class.forName(DBCreator.DRIVER);
		WebRowSet webRS = new WebRowSetImpl();
		CachedRowSetDemo.fillRowSetWithExecute(webRS);
		CachedRowSetDemo.printRowSet(webRS);

		// 输出到XML文件
		FileWriter fileWriter = new FileWriter("CUSTOMERS.xml");
		webRS.writeXml(fileWriter);

		// 创建一个空的WebRowSet，用上步生成的XML文件来填充
		WebRowSet newWebRS = new WebRowSetImpl();
		newWebRS.readXml(new FileReader("CUSTOMERS.xml"));
		System.out.println("\nRead data from CUSTOMERS.xml:");
		CachedRowSetDemo.printRowSet(newWebRS);
	}

}
