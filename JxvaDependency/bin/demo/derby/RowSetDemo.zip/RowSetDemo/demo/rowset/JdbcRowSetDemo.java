package demo.rowset;

import java.sql.SQLException;

import javax.sql.rowset.JdbcRowSet;

import com.sun.rowset.JdbcRowSetImpl;

import db.rowset.DBCreator;

public class JdbcRowSetDemo {

	public static void main(String[] args) throws SQLException,
			ClassNotFoundException {
		Class.forName(DBCreator.DRIVER);
		JdbcRowSet jrs = new JdbcRowSetImpl();
		jrs.setCommand(DBCreator.SQL_SELECT_CUSTOMERS);
		jrs.setUrl(DBCreator.DERBY_URL);
		jrs.execute();

		while (jrs.next()) {
			for (int i = 1; i <= jrs.getMetaData().getColumnCount(); i++) {
				System.out.print(jrs.getObject(i) + " "); //$NON-NLS-1$
			}
			System.out.println();
		}
	}
}
