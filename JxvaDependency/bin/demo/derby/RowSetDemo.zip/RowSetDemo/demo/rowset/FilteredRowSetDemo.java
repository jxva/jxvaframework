package demo.rowset;

import java.sql.SQLException;

import javax.sql.RowSet;
import javax.sql.rowset.FilteredRowSet;
import javax.sql.rowset.Predicate;

import com.sun.rowset.FilteredRowSetImpl;

import db.rowset.DBCreator;

public class FilteredRowSetDemo {

	public static void main(String[] args) throws SQLException,
			ClassNotFoundException {
		Class.forName(DBCreator.DRIVER);

		FilteredRowSet filterRS = new FilteredRowSetImpl();
		CachedRowSetDemo.fillRowSetWithExecute(filterRS);
		System.out.println("/*******Before set filter***********/");
		CachedRowSetDemo.printRowSet(filterRS);

		System.out.println("\n/*******After set filter***********/");
		Range range = new Range();
		filterRS.setFilter(range);
		CachedRowSetDemo.printRowSet(filterRS);

		filterRS.setFilter(null);
		filterRS.moveToInsertRow();
		filterRS.updateInt(1, 4);
		filterRS.updateString(2, "insert4");
		filterRS.insertRow();
		filterRS.moveToCurrentRow();
		filterRS.acceptChanges();
	}

}

class Range implements Predicate {

	public boolean evaluate(RowSet rs) {
		try {
			if (rs.getInt(1) > 1) {
				return true;
			}
		} catch (SQLException e) {
			// do nothing
		}
		return false;
	}

	public boolean evaluate(Object value, int column) throws SQLException {
		return false;
	}

	public boolean evaluate(Object value, String columnName)
			throws SQLException {
		return false;
	}

}
