package demo.rowset;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.sql.rowset.CachedRowSet;
import javax.sql.rowset.JdbcRowSet;
import javax.sql.rowset.JoinRowSet;

import com.sun.rowset.CachedRowSetImpl;
import com.sun.rowset.JdbcRowSetImpl;
import com.sun.rowset.JoinRowSetImpl;

import db.rowset.DBCreator;

public class JoinRowSetDemo {
	public static Connection conn;

	public static Statement stmt;

	public static void main(String[] args) throws SQLException,
			ClassNotFoundException {
		Class.forName(DBCreator.DRIVER);
		conn = DriverManager.getConnection(DBCreator.DERBY_URL);
		stmt = conn.createStatement();

		joinTwoRowSet();
		observeCursorPosition1();
		observeCursorPosition2();
		
		stmt.close();
		conn.close();
	}

	public static void joinTwoRowSet() throws SQLException {
		// 构造一个CachedRowSet并且填充CUSTOMERS表中的数据。
		CachedRowSet cachedRS = new CachedRowSetImpl();
		cachedRS.setUrl(DBCreator.DERBY_URL);
		cachedRS.setCommand(DBCreator.SQL_SELECT_CUSTOMERS);
		cachedRS.execute();

		// 构造一个JdbcRowSet并且填充ORDERS表中的数据。
		JdbcRowSet jdbcRS = new JdbcRowSetImpl();
		jdbcRS.setUrl(DBCreator.DERBY_URL);
		jdbcRS.setCommand(DBCreator.SQL_SELECT_ORDERS);
		jdbcRS.execute();

		// 把cachedRS添加进新构造的JoinRowSet中。
		JoinRowSet joinRS = new JoinRowSetImpl();
		joinRS.addRowSet(cachedRS, "ID"); //$NON-NLS-1$

		// 下面这条被注释的语句会抛出ClassCastExcepion
		// joinRS.addRowSet(jdbcRS, "ID");

		// 把jdbcRS添加进这个JoinRowSet中。
		jdbcRS.setMatchColumn("ID"); //$NON-NLS-1$
		joinRS.addRowSet(jdbcRS);

		// 观察结果：
		CachedRowSetDemo.printRowSet(joinRS);
	}

	public static void observeCursorPosition1() throws SQLException {
		// 构造一个CachedRowSet并且填充CUSTOMERS表中的数据。
		CachedRowSet cachedRS = new CachedRowSetImpl();
		cachedRS.setUrl(DBCreator.DERBY_URL);
		cachedRS.setCommand(DBCreator.SQL_SELECT_CUSTOMERS);
		cachedRS.execute();

		// 构造一个JdbcRowSet并且填充ORDERS表中的数据。
		JdbcRowSet jdbcRS = new JdbcRowSetImpl();
		jdbcRS.setUrl(DBCreator.DERBY_URL);
		jdbcRS.setCommand(DBCreator.SQL_SELECT_ORDERS);
		jdbcRS.execute();

		// 添加cachedRS.
		JoinRowSet joinRS = new JoinRowSetImpl();
		joinRS.addRowSet(cachedRS, "ID"); //$NON-NLS-1$

		// 在添加jdbcRS之前，改变指针的位置。
		jdbcRS.next();
		jdbcRS.setMatchColumn("ID"); //$NON-NLS-1$
		joinRS.addRowSet(jdbcRS);

		// 观察此时JoinRowSet中的数据。
		CachedRowSetDemo.printRowSet(joinRS);

		// 观察JoinRowSet中的列名。
		for (int i = 1; i <= joinRS.getMetaData().getColumnCount(); i++) {
			System.out.println(joinRS.getMetaData().getColumnName(i));
		}

	}

	public static void observeCursorPosition2() throws SQLException {
		// 构造一个CachedRowSet并且填充CUSTOMERS表中的数据。
		CachedRowSet cachedRS = new CachedRowSetImpl();
		cachedRS.setUrl(DBCreator.DERBY_URL);
		cachedRS.setCommand(DBCreator.SQL_SELECT_CUSTOMERS);
		cachedRS.execute();

		// 构造一个JdbcRowSet并且填充ORDERS表中的数据。
		JdbcRowSet jdbcRS = new JdbcRowSetImpl();
		jdbcRS.setUrl(DBCreator.DERBY_URL);
		jdbcRS.setCommand(DBCreator.SQL_SELECT_ORDERS);
		jdbcRS.execute();

		// 添加jdbcRS.
		JoinRowSet joinRS = new JoinRowSetImpl();
		jdbcRS.setMatchColumn("ID"); //$NON-NLS-1$
		joinRS.addRowSet(jdbcRS);

		// 在添加cachedRS之前，改变指针的位置。
		cachedRS.last();
		joinRS.addRowSet(cachedRS, "ID"); //$NON-NLS-1$

		// 观察结果。
		CachedRowSetDemo.printRowSet(joinRS);
	}
}
