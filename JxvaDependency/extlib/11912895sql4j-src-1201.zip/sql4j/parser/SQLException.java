package sql4j.parser;

/**
 * Insert the type's description here.
 * Creation date: (1/30/01 6:59:46 PM)
 * @author <Jianguo Lu>
 */
public class SQLException extends Exception{
/**
 * SQLException constructor comment.
 */
public SQLException() {
	super();
}
	public SQLException(String m){
		super(m);
	}
}