package sql4j.parser;

/**
 * Insert the type's description here.
 * Creation date: (12/17/2001 12:46:54 PM)
 * @author: Administrator
 */
public class AllDistinctPredicate {

/**
 * AllDistinctPredicate constructor comment.
 */
public AllDistinctPredicate() {
	super();
}
	public AllDistinctPredicate(String o){
	}
}