package sql4j.parser;

/**
 * Insert the type's description here.
 * Creation date: (11/1/00 9:51:25 PM)
 * @author Jianguo Lu
 */
public class SetClause {
/**
 * SetClause constructor comment.
 */
public SetClause() {
	super();
}
}