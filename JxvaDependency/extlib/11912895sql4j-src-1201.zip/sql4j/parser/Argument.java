package sql4j.parser;

/**
 * Insert the type's description here.
 * Creation date: (10/20/00 2:42:56 PM)
 * @author Jianguo Lu
 */
public class Argument {
	String name;
/**
 * Argument constructor comment.
 */
public Argument() {
	super();
}
	public Argument(String a){
		name=a;
	}
}