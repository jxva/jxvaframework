package sql4j.parser;

/**
 * Insert the type's description here.
 * Creation date: (10/31/00 12:20:01 PM)
 * @author Jianguo Lu
 */
public class ParameterRef {
/**
 * ParameterRef constructor comment.
 */
public ParameterRef() {
	super();
}
}