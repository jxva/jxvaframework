package sql4j.parser;

/**
 * Insert the type's description here.
 * Creation date: (1/8/2002 5:31:24 PM)
 * @author: Administrator
 */
public class Global {
	public static String msg;
/**
 * Global constructor comment.
 */
public Global() {
	super();
}
}
