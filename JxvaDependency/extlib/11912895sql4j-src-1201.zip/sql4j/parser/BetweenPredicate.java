package sql4j.parser;

/**
 * Insert the type's description here.
 * Creation date: (10/31/00 12:16:05 PM)
 * @author:  Jianguo Lu
 */
 
  import sql4j.schema.*;
 
public class BetweenPredicate extends AtomicWhereCondition{
/**
 * BetweenPredicate constructor comment.
 */
public BetweenPredicate() {
	super();
}
	public String toString(){
		String result="";
		return result;
	}

}