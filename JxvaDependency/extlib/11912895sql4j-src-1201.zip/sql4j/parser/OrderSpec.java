package sql4j.parser;

/**
 * Insert the type's description here.
 * Creation date: (12/17/2001 11:38:18 AM)
 * @author: Administrator
 */
public class OrderSpec {
	String order;
/**
 * OrderSpec constructor comment.
 */
public OrderSpec() {
	super();
}
	public OrderSpec(Column e1, String e2){
	}
}